#include "path_searching/dyn_a_star.h"

using namespace std;
using namespace Eigen;

AStar::~AStar()
{
    for (int i = 0; i < POOL_SIZE_(0); i++)
        for (int j = 0; j < POOL_SIZE_(1); j++)
            for (int k = 0; k < POOL_SIZE_(2); k++)
                delete GridNodeMap_[i][j][k];
}

void AStar::initGridMap(GridMap::Ptr occ_map, const Eigen::Vector3i pool_size)
{
    POOL_SIZE_ = pool_size;
    CENTER_IDX_ = pool_size / 2;

    GridNodeMap_ = new GridNodePtr **[POOL_SIZE_(0)];
    for (int i = 0; i < POOL_SIZE_(0); i++)
    {
        GridNodeMap_[i] = new GridNodePtr *[POOL_SIZE_(1)];
        for (int j = 0; j < POOL_SIZE_(1); j++)
        {
            GridNodeMap_[i][j] = new GridNodePtr[POOL_SIZE_(2)];
            for (int k = 0; k < POOL_SIZE_(2); k++)
            {
                GridNodeMap_[i][j][k] = new GridNode;
            }
        }
    }

    grid_map_ = occ_map;
}

double AStar::getDiagHeu(GridNodePtr node1, GridNodePtr node2)
{
    double dx = abs(node1->index(0) - node2->index(0));
    double dy = abs(node1->index(1) - node2->index(1));
    double dz = 0;

    double h = 0.0;
    int diag = min(dx, dy);
    dx -= diag;
    dy -= diag;
    dz -= 0;

     if (dx == 0)
    {
        h = 1.0 * sqrt(2.0) * diag + 1.0 * abs(dy);
    }
    if (dy == 0)
    {
        h = 1.0 * sqrt(2.0) * diag +  + 1.0 * abs(dx);
    }
    return h;
}

double AStar::getManhHeu(GridNodePtr node1, GridNodePtr node2)
{
    double dx = abs(node1->index(0) - node2->index(0));
    double dy = abs(node1->index(1) - node2->index(1));
    double dz = 0;

    return dx + dy ;
}

double AStar::getEuclHeu(GridNodePtr node1, GridNodePtr node2)
{
    // 只计算 x, y 距离，z 忽略
    double dx = node2->index(0) - node1->index(0);
    double dy = node2->index(1) - node1->index(1);
    return std::sqrt(dx * dx + dy * dy);
}


vector<GridNodePtr> AStar::retrievePath(GridNodePtr current)
{
    vector<GridNodePtr> path;
    path.push_back(current);

    while (current->cameFrom != NULL)
    {
        current = current->cameFrom;
        path.push_back(current);
    }

    return path;
}

bool AStar::ConvertToIndexAndAdjustStartEndPoints(Eigen::Vector3d start_pt, Eigen::Vector3d end_pt, Eigen::Vector3i &start_idx, Eigen::Vector3i &end_idx)
{
    // 强制 z = 0
    start_pt(2) = 0;
    end_pt(2) = 0;

    if (!Coord2Index(start_pt, start_idx) || !Coord2Index(end_pt, end_idx))
        return false;

    // 调整起点
    if (checkOccupancy(Index2Coord(start_idx)))
    {
        do
        {
            Eigen::Vector3d dir = (start_pt - end_pt).normalized();
            dir(2) = 0; // z 方向不动
            start_pt = start_pt + dir * step_size_;
            start_pt(2) = 0;
            if (!Coord2Index(start_pt, start_idx))
                return false;
        } while (checkOccupancy(Index2Coord(start_idx)));
    }

    // 调整终点
    if (checkOccupancy(Index2Coord(end_idx)))
    {
        do
        {
            Eigen::Vector3d dir = (end_pt - start_pt).normalized();
            dir(2) = 0; // z 方向不动
            end_pt = end_pt + dir * step_size_;
            end_pt(2) = 0;
            if (!Coord2Index(end_pt, end_idx))
                return false;
        } while (checkOccupancy(Index2Coord(end_idx)));
    }

    // 保证索引 z = 0
    start_idx(2) = 0;
    end_idx(2) = 0;

    return true;
}


bool AStar::AstarSearch(const double step_size, Vector3d start_pt, Vector3d end_pt)
{
    ros::Time time_1 = ros::Time::now();
    ++rounds_;

    step_size_ = step_size;
    inv_step_size_ = 1 / step_size;

    // z 轴固定为 0
    start_pt(2) = 0;
    end_pt(2) = 0;
    center_ = (start_pt + end_pt) / 2;

    Vector3i start_idx, end_idx;
    if (!ConvertToIndexAndAdjustStartEndPoints(start_pt, end_pt, start_idx, end_idx))
    {
        ROS_ERROR("Unable to handle the initial or end point, force return!");
        return false;
    }

    GridNodePtr startPtr = GridNodeMap_[start_idx(0)][start_idx(1)][0];
    GridNodePtr endPtr = GridNodeMap_[end_idx(0)][end_idx(1)][0];

    std::priority_queue<GridNodePtr, std::vector<GridNodePtr>, NodeComparator> empty;
    openSet_.swap(empty);

    startPtr->index = start_idx;
    startPtr->index(2) = 0; // z 固定
    startPtr->rounds = rounds_;
    startPtr->gScore = 0;
    startPtr->fScore = getHeu(startPtr, endPtr);
    startPtr->state = GridNode::OPENSET;
    startPtr->cameFrom = NULL;
    openSet_.push(startPtr);

    endPtr->index = end_idx;
    endPtr->index(2) = 0;

    double tentative_gScore;
    int num_iter = 0;

    while (!openSet_.empty())
    {
        num_iter++;
        GridNodePtr current = openSet_.top();
        openSet_.pop();

        if (current->index(0) == endPtr->index(0) && current->index(1) == endPtr->index(1))
        {
            gridPath_ = retrievePath(current);
            return true;
        }
        current->state = GridNode::CLOSEDSET;

        // 二维邻居循环，z 固定为0
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
            {
                if (dx == 0 && dy == 0)
                    continue;

                Vector3i neighborIdx;
                neighborIdx(0) = current->index(0) + dx;
                neighborIdx(1) = current->index(1) + dy;
                neighborIdx(2) = 0;

                if (neighborIdx(0) < 1 || neighborIdx(0) >= POOL_SIZE_(0) - 1 ||
                    neighborIdx(1) < 1 || neighborIdx(1) >= POOL_SIZE_(1) - 1)
                    continue;

                GridNodePtr neighborPtr = GridNodeMap_[neighborIdx(0)][neighborIdx(1)][0];
                neighborPtr->index = neighborIdx;

                bool flag_explored = neighborPtr->rounds == rounds_;
                if (flag_explored && neighborPtr->state == GridNode::CLOSEDSET)
                    continue;

                neighborPtr->rounds = rounds_;
                if (checkOccupancy(Index2Coord(neighborPtr->index)))
                    continue;

                double static_cost = std::sqrt(dx*dx + dy*dy);
                tentative_gScore = current->gScore + static_cost;

                if (!flag_explored)
                {
                    neighborPtr->state = GridNode::OPENSET;
                    neighborPtr->cameFrom = current;
                    neighborPtr->gScore = tentative_gScore;
                    neighborPtr->fScore = tentative_gScore + getHeu(neighborPtr, endPtr);
                    openSet_.push(neighborPtr);
                }
                else if (tentative_gScore < neighborPtr->gScore)
                {
                    neighborPtr->cameFrom = current;
                    neighborPtr->gScore = tentative_gScore;
                    neighborPtr->fScore = tentative_gScore + getHeu(neighborPtr, endPtr);
                }
            }

        ros::Time time_2 = ros::Time::now();
        if ((time_2 - time_1).toSec() > 0.05)
        {
            ROS_WARN("Failed in A* path searching: time limit exceeded.");
            return false;
        }
    }

    return false;
}

std::vector<Vector3d> AStar::getPath()
{
    std::vector<Vector3d> path;
    for (auto ptr : gridPath_)
    {
        Eigen::Vector3d pos = Index2Coord(ptr->index);
        pos(2) = 0; // 强制 z = 0
        path.push_back(pos);
    }
    std::reverse(path.begin(), path.end());
    return path;
}