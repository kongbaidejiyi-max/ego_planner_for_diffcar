#include "bspline_opt/uniform_bspline.h"
#include "nav_msgs/Odometry.h"
#include "ego_planner/Bspline.h"
#include "quadrotor_msgs/PositionCommand.h"
#include "std_msgs/Empty.h"
#include "visualization_msgs/Marker.h"
#include <ros/ros.h>

// 添加MPC头文件
#include "MPC.hpp"

#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/Int16.h>
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_broadcaster.h"
#include "tf2_ros/transform_listener.h"

#include <tf/message_filter.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>

ros::Publisher pos_cmd_pub;
ros::Publisher pos_vel_pub;
ros::Publisher mpc_pred_path_pub;  // MPC预测轨迹发布器

quadrotor_msgs::PositionCommand cmd;
double pos_gain[3] = {0, 0, 0};
double vel_gain[3] = {0, 0, 0};

using ego_planner::UniformBspline;
using namespace std;

bool receive_traj_ = false;
vector<UniformBspline> traj_;
double traj_duration_;
ros::Time start_time_;
int traj_id_;

// yaw control
double last_yaw_, last_yaw_dot_;
double time_forward_;
double robot_yaw_world_;

// 差速小车参数
double wheel_base_ = 0.5;  // 轮距，需要根据实际小车调整
double max_linear_vel_ = 1.0;   // 最大线速度
double max_angular_vel_ = 1.0;  // 最大角速度

// MPC控制器相关参数
MPC_controller mpc_controller_;
bool use_mpc_ = true;  // 是否使用MPC控制器
int mpc_horizon_ = 10;  // MPC预测步数
double mpc_dt_ = 0.1;   // MPC时间步长
double mpc_lookahead_time_ = 1.0;  // 前瞻时间

geometry_msgs::Pose odom_Pose;
Eigen::Vector3f odom_vel(0,0,0);

bool goFlag_=0;
void goFlagCallback(const std_msgs::Int16::ConstPtr msg);

ros::Publisher control_point_state_pub_;
nav_msgs::Odometry control_point_state;
double LimitSpeed(const double vel_input,const double upper,const double lower);

void odometryCallback(const nav_msgs::OdometryConstPtr &msg);

// MPC参考轨迹生成函数
std::pair<std::vector<Eigen::Vector3d>, std::vector<Eigen::Vector2d>> 
generateMPCReference(double t_current, int horizon, double dt)
{
    std::vector<Eigen::Vector3d> ref_states;
    std::vector<Eigen::Vector2d> ref_inputs;
    
    for(int i = 0; i < horizon; i++)
    {
        double t_ref = t_current + i * dt;
        Eigen::Vector3d pos, vel;
        
        if(t_ref < traj_duration_ && t_ref >= 0.0)
        {
            pos = traj_[0].evaluateDeBoorT(t_ref);
            vel = traj_[1].evaluateDeBoorT(t_ref);
        }
        else if(t_ref >= traj_duration_)
        {
            // 轨迹结束后保持在终点
            pos = traj_[0].evaluateDeBoorT(traj_duration_);
            vel.setZero();
        }
        else
        {
            pos.setZero();
            vel.setZero();
        }
        
        // 参考状态 [x, y, theta]
        Eigen::Vector3d ref_state;
        ref_state(0) = pos(0);
        ref_state(1) = pos(1);
        ref_state(2) = atan2(vel(1), vel(0));  // 从速度方向计算参考yaw角
        
        // 参考输入 [v, w]
        Eigen::Vector2d ref_input;
        ref_input(0) = sqrt(vel(0)*vel(0) + vel(1)*vel(1));  // 线速度
        ref_input(1) = 0.0;  // 角速度，这里简化为0，可以根据轨迹曲率计算
        
        ref_states.push_back(ref_state);
        ref_inputs.push_back(ref_input);
    }
    
    return std::make_pair(ref_states, ref_inputs);
}

// 发布MPC预测轨迹用于可视化
void publishMPCPrediction(const Eigen::MatrixXd& prediction, double t_current)
{
    nav_msgs::Path pred_path;
    pred_path.header.frame_id = "world";
    pred_path.header.stamp = ros::Time::now();
    
    // 当前状态
    double current_x = odom_Pose.position.x;
    double current_y = odom_Pose.position.y;
    double current_yaw = tf::getYaw(odom_Pose.orientation);
    
    Eigen::Vector3d state;
    state << current_x, current_y, current_yaw;
    
    for(int i = 0; i < prediction.cols(); i++)
    {
        // 使用简单的运动学模型预测状态
        double v = prediction(0, i);
        double w = prediction(1, i);
        
        // 更新状态 (简化的欧拉积分)
        state(0) += v * cos(state(2)) * mpc_dt_;
        state(1) += v * sin(state(2)) * mpc_dt_;
        state(2) += w * mpc_dt_;
        
        geometry_msgs::PoseStamped pose;
        pose.header.frame_id = "world";
        pose.header.stamp = ros::Time::now();
        pose.pose.position.x = state(0);
        pose.pose.position.y = state(1);
        pose.pose.position.z = 0.1;
        
        tf::Quaternion q;
        q.setRPY(0, 0, state(2));
        pose.pose.orientation.x = q.x();
        pose.pose.orientation.y = q.y();
        pose.pose.orientation.z = q.z();
        pose.pose.orientation.w = q.w();
        
        pred_path.poses.push_back(pose);
    }
    
    mpc_pred_path_pub.publish(pred_path);
}

void bsplineCallback(ego_planner::BsplineConstPtr msg)
{
  // parse pos traj
  Eigen::MatrixXd pos_pts(3, msg->pos_pts.size());

  Eigen::VectorXd knots(msg->knots.size());
  for (size_t i = 0; i < msg->knots.size(); ++i)
  {
    knots(i) = msg->knots[i];
  }

  for (size_t i = 0; i < msg->pos_pts.size(); ++i)
  {
    pos_pts(0, i) = msg->pos_pts[i].x;
    pos_pts(1, i) = msg->pos_pts[i].y;
    pos_pts(2, i) = msg->pos_pts[i].z;
  }

  UniformBspline pos_traj(pos_pts, msg->order, 0.1);
  pos_traj.setKnot(knots);

  start_time_ = msg->start_time;
  traj_id_ = msg->traj_id;

  traj_.clear();
  traj_.push_back(pos_traj);
  traj_.push_back(traj_[0].getDerivative());
  traj_.push_back(traj_[1].getDerivative());

  traj_duration_ = traj_[0].getTimeSum();

  receive_traj_ = true;
  
  ROS_INFO("Received new B-spline trajectory, duration: %.2f", traj_duration_);
}

// 差速小车的yaw角计算（保留原有方法作为备用）
std::pair<double, double> calculate_yaw_differential(double t_cur, Eigen::Vector3d &pos, Eigen::Vector3d &vel)
{
  constexpr double PI = 3.1415926;
  std::pair<double, double> yaw_yawdot(0, 0);
  
  // 从速度方向计算期望的yaw角
  double desired_yaw = atan2(vel(1), vel(0));
  
  // 获取当前机器人的yaw角
  double current_yaw = tf::getYaw(odom_Pose.orientation);
  
  // 计算yaw角差值，处理角度跳跃
  double yaw_diff = desired_yaw - current_yaw;
  if (yaw_diff > PI) yaw_diff = yaw_diff - 2 * PI;
  else if (yaw_diff < -PI) yaw_diff = yaw_diff + 2 * PI;
  
  yaw_yawdot.first = yaw_diff;
  
  // 简单的角速度控制，可以调整增益
  double yaw_gain = 2.0;
  yaw_yawdot.second = yaw_gain * yaw_diff;
  
  // 限制角速度
  yaw_yawdot.second = LimitSpeed(yaw_yawdot.second, max_angular_vel_, -max_angular_vel_);

  return yaw_yawdot;
}

void goFlagCallback(const std_msgs::Int16::ConstPtr msg)
{
  goFlag_ = msg->data;
}

void cmdCallback(const ros::TimerEvent &e)
{
  /* no publishing before receive traj_ */
  if (!receive_traj_)
    return;

  geometry_msgs::Twist robotVelocity_BASE_frame;
  
  if(!goFlag_)
  {
    // 停止小车
    robotVelocity_BASE_frame.linear.x = 0;
    robotVelocity_BASE_frame.linear.y = 0;
    robotVelocity_BASE_frame.linear.z = 0;
    robotVelocity_BASE_frame.angular.x = 0;
    robotVelocity_BASE_frame.angular.y = 0;
    robotVelocity_BASE_frame.angular.z = 0;

    pos_vel_pub.publish(robotVelocity_BASE_frame);
    return;
  }
  
  ros::Time time_now = ros::Time::now();
  double t_cur = (time_now - start_time_).toSec();

  Eigen::Vector3d pos(Eigen::Vector3d::Zero()), vel(Eigen::Vector3d::Zero()), acc(Eigen::Vector3d::Zero()), pos_f;
  std::pair<double, double> yaw_yawdot(0, 0);

  static ros::Time time_last = ros::Time::now();
  
  if (t_cur < traj_duration_ && t_cur >= 0.0)
  {
    pos = traj_[0].evaluateDeBoorT(t_cur);
    vel = traj_[1].evaluateDeBoorT(t_cur);
    acc = traj_[2].evaluateDeBoorT(t_cur);

    double tf = min(traj_duration_, t_cur + 2.0);
    pos_f = traj_[0].evaluateDeBoorT(tf);
  }
  else if (t_cur >= traj_duration_)
  {
    /* hover when finish traj_ */
    pos = traj_[0].evaluateDeBoorT(traj_duration_);
    vel.setZero();
    acc.setZero();
    pos_f = pos;
  }
  else
  {
    cout << "[Traj server]: invalid time." << endl;
    return;
  }
  
  time_last = time_now;

  // ========== MPC控制器部分 ========== //
  if(use_mpc_)
  {
    try 
    {
      // 获取当前状态
      Eigen::Vector3d current_state;
      current_state(0) = odom_Pose.position.x;
      current_state(1) = odom_Pose.position.y;
      current_state(2) = tf::getYaw(odom_Pose.orientation);
      
      // 生成MPC参考轨迹
      auto mpc_ref = generateMPCReference(t_cur, mpc_horizon_, mpc_dt_);
      
      // 调用MPC求解器
      Eigen::MatrixXd mpc_result = mpc_controller_.MPC_Solve_qp(
          current_state, 
          mpc_ref.first, 
          mpc_ref.second, 
          mpc_horizon_
      );
      
      // 取第一个控制输入
      double v_cmd = mpc_result(0, 0);
      double w_cmd = mpc_result(1, 0);
      
      // 限制速度
      v_cmd = LimitSpeed(v_cmd, max_linear_vel_, 0.0);
      w_cmd = LimitSpeed(w_cmd, max_angular_vel_, -max_angular_vel_);
      
      robotVelocity_BASE_frame.linear.x = v_cmd;
      robotVelocity_BASE_frame.linear.y = 0;
      robotVelocity_BASE_frame.linear.z = 0;
      robotVelocity_BASE_frame.angular.x = 0;
      robotVelocity_BASE_frame.angular.y = 0;
      robotVelocity_BASE_frame.angular.z = w_cmd;
      
      // 发布MPC预测轨迹用于可视化
      publishMPCPrediction(mpc_result, t_cur);
      
      cout << "MPC Control - v: " << v_cmd << " w: " << w_cmd << endl;
      
      // 更新yaw信息用于位置命令
      yaw_yawdot.first = current_state(2);
      yaw_yawdot.second = w_cmd;
    }
    catch(const std::exception& e)
    {
      ROS_WARN("MPC solver failed: %s, falling back to original control", e.what());
      use_mpc_ = false;
    }
  }
  
  // ========== 原始控制方法（备用） ========== //
  if(!use_mpc_)
  {
    /*** 差速小车的yaw角计算 ***/
    yaw_yawdot = calculate_yaw_differential(t_cur, pos, vel);
    
    // 计算期望的线速度（世界坐标系）
    double desired_linear_vel = sqrt(vel(0)*vel(0) + vel(1)*vel(1));
    
    // 限制最大线速度
    desired_linear_vel = LimitSpeed(desired_linear_vel, max_linear_vel_, 0.0);
    
    // 差速小车只能前进/后退，不能侧向移动
    robotVelocity_BASE_frame.linear.x = desired_linear_vel;
    robotVelocity_BASE_frame.linear.y = 0;
    robotVelocity_BASE_frame.linear.z = 0;
    robotVelocity_BASE_frame.angular.x = 0;
    robotVelocity_BASE_frame.angular.y = 0;
    robotVelocity_BASE_frame.angular.z = yaw_yawdot.second;
    
    cout << "Original Control - linear_vel: " << robotVelocity_BASE_frame.linear.x 
         << "  angular_vel: " << robotVelocity_BASE_frame.angular.z << endl;
  }

  // 发布位置命令（保持原有逻辑）
  cmd.header.stamp = time_now;
  cmd.header.frame_id = "world";
  cmd.trajectory_flag = quadrotor_msgs::PositionCommand::TRAJECTORY_STATUS_READY;
  cmd.trajectory_id = traj_id_;

  cmd.position.x = pos(0);
  cmd.position.y = pos(1);
  cmd.position.z = pos(2);
  cmd.yaw = yaw_yawdot.first;
 
  cmd.velocity.x = vel(0);
  cmd.velocity.y = vel(1);
  cmd.velocity.z = vel(2);
  cmd.yaw_dot = yaw_yawdot.second;

  cmd.acceleration.x = acc(0);
  cmd.acceleration.y = acc(1);
  cmd.acceleration.z = acc(2);
  last_yaw_ = cmd.yaw;

  pos_cmd_pub.publish(cmd);

  // ------------ 发布control point状态 ------------- //
  control_point_state.header.frame_id = "world";
  control_point_state.header.stamp = time_now;
  
  // 从轨迹速度估计yaw角
  double yaw_estimate_from_traj = atan2(vel(1), vel(0));
  
  Eigen::AngleAxisd yawAngle(yaw_estimate_from_traj, Eigen::Vector3d::UnitZ());
  Eigen::Quaterniond q_estimate(yawAngle);

  control_point_state.pose.pose.position.x = pos(0);
  control_point_state.pose.pose.position.y = pos(1);
  control_point_state.pose.pose.position.z = pos(2);
  control_point_state.pose.pose.orientation.x = q_estimate.x();
  control_point_state.pose.pose.orientation.y = q_estimate.y();
  control_point_state.pose.pose.orientation.z = q_estimate.z();
  control_point_state.pose.pose.orientation.w = q_estimate.w();
    
  control_point_state_pub_.publish(control_point_state);

  pos_vel_pub.publish(robotVelocity_BASE_frame);
}

void odometryCallback(const nav_msgs::OdometryConstPtr &msg)
{
  odom_Pose.position.x = msg->pose.pose.position.x;
  odom_Pose.position.y = msg->pose.pose.position.y;
  odom_Pose.position.z = msg->pose.pose.position.z;

  odom_Pose.orientation.x = msg->pose.pose.orientation.x;
  odom_Pose.orientation.y = msg->pose.pose.orientation.y;
  odom_Pose.orientation.z = msg->pose.pose.orientation.z;
  odom_Pose.orientation.w = msg->pose.pose.orientation.w;

  Eigen::Quaterniond q(msg->pose.pose.orientation.w,
                        msg->pose.pose.orientation.x,
                        msg->pose.pose.orientation.y,
                        msg->pose.pose.orientation.z);

  robot_yaw_world_ = q.matrix().eulerAngles(2,1,0)(0);

  // 获取当前速度（用于反馈控制，如果需要的话）
  odom_vel(0) = msg->twist.twist.linear.x;
  odom_vel(1) = msg->twist.twist.linear.y;
  odom_vel(2) = msg->twist.twist.angular.z;
}

double LimitSpeed(const double vel_input, const double upper, const double lower)
{
  double vel_output;
  if(vel_input > upper) vel_output = upper;
  else if(vel_input < lower) vel_output = lower;
  else vel_output = vel_input;

  return vel_output;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "mpc_differential_drive_traj_server");
  ros::NodeHandle node;
  ros::NodeHandle nh("~");

  control_point_state.pose.pose.orientation.w = 1;

  // 获取差速小车参数
  nh.param("wheel_base", wheel_base_, 0.5);
  nh.param("max_linear_vel", max_linear_vel_, 1.0);
  nh.param("max_angular_vel", max_angular_vel_, 2.0);
  
  // 获取MPC参数
  nh.param("use_mpc", use_mpc_, true);
  nh.param("mpc_horizon", mpc_horizon_, 10);
  nh.param("mpc_dt", mpc_dt_, 0.1);
  nh.param("mpc_lookahead_time", mpc_lookahead_time_, 1.0);

  // 初始化MPC控制器
  if(use_mpc_)
  {
    try 
    {
      mpc_controller_.MPC_init(nh);
      ROS_INFO("MPC controller initialized successfully");
    }
    catch(const std::exception& e)
    {
      ROS_ERROR("Failed to initialize MPC controller: %s", e.what());
      ROS_WARN("Falling back to original control method");
      use_mpc_ = false;
    }
  }

  ros::Subscriber bspline_sub = node.subscribe("planning/bspline", 10, bsplineCallback);
  ros::Subscriber legOdom_sub = node.subscribe("car/Odometry", 10, odometryCallback);
  ros::Subscriber goFlagSub = node.subscribe("ego_planner_node/go_flag", 10, goFlagCallback);

  pos_cmd_pub = node.advertise<quadrotor_msgs::PositionCommand>("/position_cmd", 50);
  pos_vel_pub = node.advertise<geometry_msgs::Twist>("/car/cmd_vel", 50);
  mpc_pred_path_pub = node.advertise<nav_msgs::Path>("/mpc_prediction", 10);

  ros::Timer cmd_timer = node.createTimer(ros::Duration(0.1), cmdCallback);
  control_point_state_pub_ = node.advertise<nav_msgs::Odometry>("/control_point_state_", 10);

  /* control parameter */
  cmd.kx[0] = pos_gain[0];
  cmd.kx[1] = pos_gain[1];
  cmd.kx[2] = pos_gain[2];

  cmd.kv[0] = vel_gain[0];
  cmd.kv[1] = vel_gain[1];
  cmd.kv[2] = vel_gain[2];

  nh.param("traj_server/time_forward", time_forward_, -1.0);
  last_yaw_ = 0.0;
  last_yaw_dot_ = 0.0;

  ros::Duration(1.0).sleep();

  if(use_mpc_)
    ROS_WARN("[MPC Differential Drive Traj server]: ready with MPC control.");
  else
    ROS_WARN("[Differential Drive Traj server]: ready with original control.");

  ros::spin();

  return 0;
}