#include "bspline_opt/uniform_bspline.h"
#include "nav_msgs/Odometry.h"
#include "ego_planner/Bspline.h"
#include "quadrotor_msgs/PositionCommand.h"
#include "std_msgs/Empty.h"
#include "std_msgs/Int16.h"
#include "visualization_msgs/Marker.h"
#include <ros/ros.h>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf/transform_listener.h>
#include <tf/tf.h>

#include <algorithm>
#include <cmath>

using ego_planner::UniformBspline;
using namespace std;

// ROS发布器
ros::Publisher pos_cmd_pub;
ros::Publisher cmd_vel_pub;
ros::Publisher control_point_state_pub;

// 轨迹相关变量
bool receive_traj_ = false;
vector<UniformBspline> traj_;
double traj_duration_;
ros::Time start_time_;
int traj_id_;

// 差速小车参数
struct DifferentialDriveParams {
    double max_linear_vel = 2.0;      // 最大线速度 (m/s)
    double max_angular_vel = 2.0;     // 最大角速度 (rad/s)
    double max_linear_acc = 1.0;      // 最大线加速度 (m/s²)
    double max_angular_acc = 1.0;     // 最大角加速度 (rad/s²)
    double wheelbase = 0.5;           // 轴距 (m)
    double position_tolerance = 0.05; // 位置容差 (m)
    double yaw_tolerance = 0.1;       // 角度容差 (rad)
    
    // PID参数
    struct {
        double kp = 1.0, ki = 0.0, kd = 0.1;  // 位置PID参数
    } position_pid;
    
    struct {
        double kp = 1.0, ki = 0.0, kd = 0.1;  // 角度PID参数  
    } yaw_pid;
};

DifferentialDriveParams robot_params;

// 控制相关变量
geometry_msgs::Pose current_pose;
geometry_msgs::Twist current_velocity;
double current_yaw = 0.0;
bool go_flag = false;

// PID控制器类
class PIDController {
private:
    double kp_, ki_, kd_;
    double integral_;
    double previous_error_;
    double dt_;
    double integral_max_;
    bool first_run_;
    
public:
    PIDController(double kp, double ki, double kd, double dt, double integral_max = 1.0) 
        : kp_(kp), ki_(ki), kd_(kd), dt_(dt), integral_max_(integral_max),
          integral_(0.0), previous_error_(0.0), first_run_(true) {}
    
    double compute(double error) {
        if (first_run_) {
            previous_error_ = error;
            first_run_ = false;
        }
        
        // 比例项
        double proportional = kp_ * error;
        
        // 积分项
        integral_ += error * dt_;
        // 积分限幅
        integral_ = std::max(-integral_max_, std::min(integral_max_, integral_));
        double integral_term = ki_ * integral_;
        
        // 微分项
        double derivative = kd_ * (error - previous_error_) / dt_;
        
        previous_error_ = error;
        
        return proportional + integral_term + derivative;
    }
    
    void reset() {
        integral_ = 0.0;
        previous_error_ = 0.0;
        first_run_ = true;
    }
    
    void updateParams(double kp, double ki, double kd) {
        kp_ = kp;
        ki_ = ki; 
        kd_ = kd;
    }
};

// 差速小车PID控制器类
class DifferentialDrivePIDController {
private:
    PIDController* position_pid_;
    PIDController* yaw_pid_;
    double dt_;
    
public:
    DifferentialDrivePIDController(const DifferentialDriveParams& params, double dt) : dt_(dt) {
        position_pid_ = new PIDController(
            params.position_pid.kp, 
            params.position_pid.ki, 
            params.position_pid.kd, 
            dt, 
            1.0  // 积分限幅
        );
        
        yaw_pid_ = new PIDController(
            params.yaw_pid.kp, 
            params.yaw_pid.ki, 
            params.yaw_pid.kd, 
            dt, 
            1.0  // 积分限幅
        );
    }
    
    ~DifferentialDrivePIDController() {
        delete position_pid_;
        delete yaw_pid_;
    }
    
    geometry_msgs::Twist computeVelocityCommand(
    const geometry_msgs::Pose& current_pose,
    const Eigen::Vector3d& target_pos,
    const Eigen::Vector3d& target_vel,
    double current_yaw) {
    
    geometry_msgs::Twist cmd_vel;
    cmd_vel.linear.x = 0.0;
    cmd_vel.linear.y = 0.0;  // 差速小车无侧向运动
    cmd_vel.linear.z = 0.0;
    cmd_vel.angular.x = 0.0;
    cmd_vel.angular.y = 0.0;
    cmd_vel.angular.z = 0.0;
    
    // 计算位置误差
    double dx = target_pos.x() - current_pose.position.x;
    double dy = target_pos.y() - current_pose.position.y;
    double position_error = sqrt(dx*dx + dy*dy);
    
    // 如果已经到达目标点，停止运动
    if (position_error < robot_params.position_tolerance) {
        return cmd_vel;
    }
    
    // 计算目标航向角（从当前位置到目标位置的方向）
    double target_yaw = atan2(dy, dx);
    
    // 计算航向角误差并标准化到[-π, π]
    double yaw_error = target_yaw - current_yaw;
    while (yaw_error > M_PI) yaw_error -= 2.0 * M_PI;
    while (yaw_error < -M_PI) yaw_error += 2.0 * M_PI;
    
    // 使用PID控制器计算控制量
    double linear_control = position_pid_->compute(position_error);
    double angular_control = yaw_pid_->compute(yaw_error);
    
    // 简单的角度前馈：基于轨迹速度方向
    double feedforward_angular = 0.0;
    double linear_speed = sqrt(target_vel.x()*target_vel.x() + target_vel.y()*target_vel.y());
    if (linear_speed > 0.01) {
        // 计算轨迹速度的方向（期望偏航角）
        double vel_yaw = atan2(target_vel.y(), target_vel.x());
        // 计算角度误差作为前馈角速度的基础
        double yaw_rate = vel_yaw - current_yaw;
        while (yaw_rate > M_PI) yaw_rate -= 2.0 * M_PI;
        while (yaw_rate < -M_PI) yaw_rate += 2.0 * M_PI;
        // 简单前馈：角速度 = 角度误差 / 时间步长，缩放以匹配速度
        feedforward_angular = (yaw_rate / dt_) * 0.5; // 缩放因子0.5以避免过大
        // 限幅前馈角速度
        // feedforward_angular = std::max(-robot_params.max_angular_vel, 
        //                              std::min(robot_params.max_angular_vel, feedforward_angular));
    }
    
    // 组合PID控制和角度前馈
    double total_angular = angular_control + feedforward_angular;
    
    // 如果角度误差过大，优先转向
    if (fabs(yaw_error) > robot_params.yaw_tolerance) {
        // 角度误差大时，减小线速度，增大角速度权重
        double angle_factor = std::max(0.1, 1.0 - 2.0 * fabs(yaw_error) / M_PI);
        cmd_vel.linear.x = linear_control * angle_factor;
        cmd_vel.angular.z = total_angular;
    } else {
        // 角度误差小时，正常前进
        cmd_vel.linear.x = linear_control;
        cmd_vel.angular.z = total_angular * 0.5;  // 减小角速度增益
    }
    
    // 结合轨迹期望速度进行线速度前馈补偿（保留原有逻辑）
    double feedforward_speed = sqrt(target_vel.x()*target_vel.x() + target_vel.y()*target_vel.y());
    if (feedforward_speed > 0.01 && fabs(yaw_error) < robot_params.yaw_tolerance) {
        // 只有在角度对准的情况下才使用线速度前馈
        cmd_vel.linear.x = std::max(cmd_vel.linear.x, feedforward_speed * 0.5);
    }
    
    // 速度限幅
    cmd_vel.linear.x = std::max(-robot_params.max_linear_vel, 
                               std::min(robot_params.max_linear_vel, cmd_vel.linear.x));
    cmd_vel.angular.z = std::max(-robot_params.max_angular_vel, 
                                std::min(robot_params.max_angular_vel, cmd_vel.angular.z));
    
    // 调试信息
    ROS_INFO_THROTTLE(1.0, "Feedforward Angular: %.3f | Total Angular: %.3f", 
                     feedforward_angular, cmd_vel.angular.z);
    
    return cmd_vel;
}
    
    void reset() {
        position_pid_->reset();
        yaw_pid_->reset();
    }
    
    void updatePositionPID(double kp, double ki, double kd) {
        position_pid_->updateParams(kp, ki, kd);
    }
    
    void updateYawPID(double kp, double ki, double kd) {
        yaw_pid_->updateParams(kp, ki, kd);
    }
};

DifferentialDrivePIDController* pid_controller;

// 速度平滑器类
class VelocitySmoother {
private:
    geometry_msgs::Twist last_velocity_;
    double max_linear_acc_;
    double max_angular_acc_;
    double dt_;
    
public:
    VelocitySmoother(double max_lin_acc, double max_ang_acc, double dt) 
        : max_linear_acc_(max_lin_acc), max_angular_acc_(max_ang_acc), dt_(dt) {
        last_velocity_.linear.x = 0.0;
        last_velocity_.angular.z = 0.0;
    }
    
    geometry_msgs::Twist smoothVelocity(const geometry_msgs::Twist& target_vel) {
        geometry_msgs::Twist smooth_vel = target_vel;
        
        // 线速度平滑
        double linear_acc = (target_vel.linear.x - last_velocity_.linear.x) / dt_;
        if (linear_acc > max_linear_acc_) {
            smooth_vel.linear.x = last_velocity_.linear.x + max_linear_acc_ * dt_;
        } else if (linear_acc < -max_linear_acc_) {
            smooth_vel.linear.x = last_velocity_.linear.x - max_linear_acc_ * dt_;
        }
        
        // 角速度平滑
        double angular_acc = (target_vel.angular.z - last_velocity_.angular.z) / dt_;
        if (angular_acc > max_angular_acc_) {
            smooth_vel.angular.z = last_velocity_.angular.z + max_angular_acc_ * dt_;
        } else if (angular_acc < -max_angular_acc_) {
            smooth_vel.angular.z = last_velocity_.angular.z - max_angular_acc_ * dt_;
        }
        
        // 速度限幅
        smooth_vel.linear.x = std::max(-robot_params.max_linear_vel, 
                             std::min(robot_params.max_linear_vel, smooth_vel.linear.x));
        smooth_vel.angular.z = std::max(-robot_params.max_angular_vel, 
                              std::min(robot_params.max_angular_vel, smooth_vel.angular.z));
        
        last_velocity_ = smooth_vel;
        return smooth_vel;
    }
    
    void reset() {
        last_velocity_.linear.x = 0.0;
        last_velocity_.angular.z = 0.0;
    }
};

VelocitySmoother* velocity_smoother;

// 回调函数声明
void goFlagCallback(const std_msgs::Int16::ConstPtr& msg);
void odometryCallback(const nav_msgs::OdometryConstPtr& msg);
void bsplineCallback(ego_planner::BsplineConstPtr msg);
void cmdCallback(const ros::TimerEvent& e);

// 实现goFlagCallback
void goFlagCallback(const std_msgs::Int16::ConstPtr& msg) {
    bool new_go_flag = (msg->data != 0);
    
    if (new_go_flag != go_flag) {
        go_flag = new_go_flag;
        
        if (!go_flag) {
            // 停止时重置控制器
            pid_controller->reset();
            velocity_smoother->reset();
            ROS_INFO("Motion stopped - PID controllers reset");
        } else {
            ROS_INFO("Motion started");
        }
    }
}

// 实现bsplineCallback
void bsplineCallback(ego_planner::BsplineConstPtr msg) {
    // 解析位置轨迹
    Eigen::MatrixXd pos_pts(3, msg->pos_pts.size());
    Eigen::VectorXd knots(msg->knots.size());
    
    for (size_t i = 0; i < msg->knots.size(); ++i) {
        knots(i) = msg->knots[i];
    }
    
    for (size_t i = 0; i < msg->pos_pts.size(); ++i) {
        pos_pts(0, i) = msg->pos_pts[i].x;
        pos_pts(1, i) = msg->pos_pts[i].y;
        pos_pts(2, i) = msg->pos_pts[i].z;
    }
    
    UniformBspline pos_traj(pos_pts, msg->order, 0.1);
    pos_traj.setKnot(knots);
    
    start_time_ = msg->start_time;
    traj_id_ = msg->traj_id;
    
    traj_.clear();
    traj_.push_back(pos_traj);                    // 位置轨迹
    traj_.push_back(traj_[0].getDerivative());    // 速度轨迹
    traj_.push_back(traj_[1].getDerivative());    // 加速度轨迹
    
    traj_duration_ = traj_[0].getTimeSum();
    receive_traj_ = true;
    
    // 重置PID控制器，开始新轨迹
    pid_controller->reset();
    
    ROS_INFO("Received new B-spline trajectory with duration: %.2f seconds", traj_duration_);
}

// 主要控制回调函数
void cmdCallback(const ros::TimerEvent& e) {
    geometry_msgs::Twist cmd_vel;
    cmd_vel.linear.x = 0.0;
    cmd_vel.linear.y = 0.0;
    cmd_vel.linear.z = 0.0;
    cmd_vel.angular.x = 0.0;
    cmd_vel.angular.y = 0.0;
    cmd_vel.angular.z = 0.0;
    
    // 如果没有收到轨迹或停止标志，发布零速度
    if (!receive_traj_ || !go_flag) {
        cmd_vel = velocity_smoother->smoothVelocity(cmd_vel);  // 平滑停止
        cmd_vel_pub.publish(cmd_vel);
        return;
    }
    
    ros::Time time_now = ros::Time::now();
    // double t_cur = (time_now - start_time_).toSec();
    double t_cur=1.3;
    
    Eigen::Vector3d target_pos, target_vel, target_acc;
    
    if (t_cur >= 0.0 && t_cur < traj_duration_) {
        // 轨迹跟踪阶段
        target_pos = traj_[0].evaluateDeBoorT(t_cur);
        target_vel = traj_[1].evaluateDeBoorT(t_cur);
        target_acc = traj_[2].evaluateDeBoorT(t_cur);
        
        // 使用PID控制器计算控制命令
        cmd_vel = pid_controller->computeVelocityCommand(current_pose, target_pos, target_vel, current_yaw);
        
    } else if (t_cur >= traj_duration_) {
        // 轨迹结束，移动到终点并停止
        target_pos = traj_[0].evaluateDeBoorT(traj_duration_);
        target_vel.setZero();
        target_acc.setZero();
        
        // 计算到终点的距离
        double dx = target_pos.x() - current_pose.position.x;
        double dy = target_pos.y() - current_pose.position.y;
        double distance_to_end = sqrt(dx*dx + dy*dy);
        
        if (distance_to_end > robot_params.position_tolerance) {
            // 还没到达终点，继续使用PID控制
            cmd_vel = pid_controller->computeVelocityCommand(
                current_pose, target_pos, target_vel, current_yaw);
        } else {
            // 已到达终点，停止运动
            cmd_vel.linear.x = 0.0;
            cmd_vel.angular.z = 0.0;
            ROS_INFO_THROTTLE(2.0, "Trajectory completed - arrived at target position");
        }
    } else {
        // 轨迹还未开始
        ROS_INFO_THROTTLE(2.0, "Waiting for trajectory to start... t=%.2f", t_cur);
        cmd_vel.linear.x = 0.0;
        cmd_vel.angular.z = 0.0;
    }
    
    // 速度平滑处理
    cmd_vel = velocity_smoother->smoothVelocity(cmd_vel);
    
    // 发布控制命令
    cmd_vel_pub.publish(cmd_vel);
    
    // 发布位置命令（用于可视化或其他模块）
    quadrotor_msgs::PositionCommand pos_cmd;
    pos_cmd.header.stamp = time_now;
    pos_cmd.header.frame_id = "camera_init";
    pos_cmd.trajectory_flag = quadrotor_msgs::PositionCommand::TRAJECTORY_STATUS_READY;
    pos_cmd.trajectory_id = traj_id_;
    
    if (t_cur >= 0.0 && t_cur <= traj_duration_) {
        pos_cmd.position.x = target_pos.x();
        pos_cmd.position.y = target_pos.y();
        pos_cmd.position.z = target_pos.z();
        
        pos_cmd.velocity.x = target_vel.x();
        pos_cmd.velocity.y = target_vel.y();
        pos_cmd.velocity.z = target_vel.z();
        
        pos_cmd.acceleration.x = target_acc.x();
        pos_cmd.acceleration.y = target_acc.y();
        pos_cmd.acceleration.z = target_acc.z();
    }
    
    pos_cmd_pub.publish(pos_cmd);
    
    // 计算当前误差用于调试
    double current_distance_error = 0.0;
    double current_yaw_error = 0.0;
    
    if (t_cur >= 0.0 && t_cur <= traj_duration_) {
        double dx = target_pos.x() - current_pose.position.x;
        double dy = target_pos.y() - current_pose.position.y;
        current_distance_error = sqrt(dx*dx + dy*dy);
        
        double target_yaw = atan2(dy, dx);
        current_yaw_error = target_yaw - current_yaw;
        while (current_yaw_error > M_PI) current_yaw_error -= 2.0 * M_PI;
        while (current_yaw_error < -M_PI) current_yaw_error += 2.0 * M_PI;
    }
    
    // 调试信息
    ROS_INFO_THROTTLE(1.0, "PID Control - Linear: %.3f, Angular: %.3f | Errors - Pos: %.3f, Yaw: %.3f", 
                     cmd_vel.linear.x, cmd_vel.angular.z, 
                     current_distance_error, current_yaw_error);
}

// 里程计回调函数
void odometryCallback(const nav_msgs::OdometryConstPtr& msg) {
    // 更新当前位姿
    current_pose.position = msg->pose.pose.position;
    current_pose.orientation = msg->pose.pose.orientation;
    
    // 更新当前速度
    current_velocity = msg->twist.twist;
    
    // 计算当前偏航角
    current_yaw = tf::getYaw(msg->pose.pose.orientation);
    
    // 发布控制点状态（用于可视化）
    nav_msgs::Odometry control_point_state;
    control_point_state.header = msg->header;
    control_point_state.pose = msg->pose;
    control_point_state.twist = msg->twist;
    control_point_state_pub.publish(control_point_state);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "traj_server");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");
    
    // 读取运动参数
    private_nh.param("max_linear_vel", robot_params.max_linear_vel, 1.0);
    private_nh.param("max_angular_vel", robot_params.max_angular_vel, 2.0);
    private_nh.param("max_linear_acc", robot_params.max_linear_acc, 1.0);
    private_nh.param("max_angular_acc", robot_params.max_angular_acc, 2.0);
    private_nh.param("position_tolerance", robot_params.position_tolerance, 0.05);
    private_nh.param("yaw_tolerance", robot_params.yaw_tolerance, 0.1);
    private_nh.param("wheelbase", robot_params.wheelbase, 0.5);
    
    // 读取PID参数
    private_nh.param("position_pid/kp", robot_params.position_pid.kp, 1.0);
    private_nh.param("position_pid/ki", robot_params.position_pid.ki, 0.0);
    private_nh.param("position_pid/kd", robot_params.position_pid.kd, 0.1);
    
    private_nh.param("yaw_pid/kp", robot_params.yaw_pid.kp, 2.0);
    private_nh.param("yaw_pid/ki", robot_params.yaw_pid.ki, 0.0);
    private_nh.param("yaw_pid/kd", robot_params.yaw_pid.kd, 0.1);
    
    ROS_INFO("=== Differential Drive PID Controller Parameters ===");
    ROS_INFO("Motion Limits:");
    ROS_INFO("  Max linear velocity: %.2f m/s", robot_params.max_linear_vel);
    ROS_INFO("  Max angular velocity: %.2f rad/s", robot_params.max_angular_vel);
    ROS_INFO("  Max linear acceleration: %.2f m/s²", robot_params.max_linear_acc);
    ROS_INFO("  Max angular acceleration: %.2f rad/s²", robot_params.max_angular_acc);
    ROS_INFO("Tolerances:");
    ROS_INFO("  Position tolerance: %.3f m", robot_params.position_tolerance);
    ROS_INFO("  Yaw tolerance: %.3f rad (%.1f°)", robot_params.yaw_tolerance, robot_params.yaw_tolerance*180/M_PI);
    ROS_INFO("PID Parameters:");
    ROS_INFO("  Position PID: Kp=%.2f, Ki=%.3f, Kd=%.3f", 
             robot_params.position_pid.kp, robot_params.position_pid.ki, robot_params.position_pid.kd);
    ROS_INFO("  Yaw PID: Kp=%.2f, Ki=%.3f, Kd=%.3f", 
             robot_params.yaw_pid.kp, robot_params.yaw_pid.ki, robot_params.yaw_pid.kd);
    
    // 初始化控制器
    pid_controller = new DifferentialDrivePIDController(robot_params, 0.1);  // 控制周期0.1秒
    
    velocity_smoother = new VelocitySmoother(
        robot_params.max_linear_acc, 
        robot_params.max_angular_acc, 
        0.1);  // 控制周期为0.1秒
    
    // 设置订阅者
    ros::Subscriber bspline_sub = nh.subscribe("planning/bspline", 10, bsplineCallback);
    ros::Subscriber odom_sub = nh.subscribe("car/Odometry", 10, odometryCallback);
    ros::Subscriber go_flag_sub = nh.subscribe("ego_planner_node/go_flag", 50, goFlagCallback);
    
    // 设置发布者
    pos_cmd_pub = nh.advertise<quadrotor_msgs::PositionCommand>("/position_cmd", 50);
    cmd_vel_pub = nh.advertise<geometry_msgs::Twist>("/car/cmd_vel", 10);
    control_point_state_pub = nh.advertise<nav_msgs::Odometry>("/control_point_state", 10);
    
    // 创建控制定时器（100Hz）
    ros::Timer cmd_timer = nh.createTimer(ros::Duration(0.01), cmdCallback);
    
    ROS_WARN("Differential Drive PID Trajectory Server Ready!");
    ROS_INFO("Subscribed to:");
    ROS_INFO("  - /planning/bspline (trajectory input)");
    ROS_INFO("  - /car/Odometry (robot state)");
    ROS_INFO("  - /ego_planner_node/go_flag (motion enable)");
    ROS_INFO("Publishing to:");
    ROS_INFO("  - /car/cmd_vel (velocity commands)");
    ROS_INFO("  - /position_cmd (trajectory state)");
    
    ros::spin();
    
    // 清理资源
    delete pid_controller;
    delete velocity_smoother;
    
    return 0;
}