^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ackermann_vehicle
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2015-09-18)
------------------
* Changed the version to 0.1.3.

0.1.2 (2015-08-19)
------------------
* Added the architecture_independent element to package.xml.

0.1.1 (2014-09-26)
------------------

0.1.0 (2014-09-18)
------------------
* Initial release.
